/* =========================================================
   Jazz Cafe 주문 키오스크 — 동작 (js/script.js)

      ★ STEP 번호 순서대로, 주석 아래에 코드를 직접 입력하세요.
      각 STEP 이 끝날 때마다 브라우저에서 새로고침하여 확인합니다.

   목차 (완성했을 때의 구역)
     1. 요소 선택
     2. 데이터 (menus, cart 와 상태 값)
     3. 도움 함수 (won, findMenu, 합계 계산)
     3-2. 저장하기 / 불러오기 (saveState, loadState)
     4. 장바구니 데이터를 바꾸는 함수 (addToCart, changeQty, removeFromCart)
     5. 화면 그리기 (renderTabs, renderMenu, renderPlace, renderCart)
     6. 이벤트 (매장/포장, 전체 취소, 주문하기, 주문 완료 창 닫기)
     7. 처음 화면 그리기

   핵심 구조 (To-do List 와 같은 방식)
     1) 데이터(배열)가 '진짜 데이터'이다.  → menus, cart
     2) 데이터가 바뀌면 render 함수를 다시 부른다.
     3) 이벤트(클릭)는 '데이터만 바꾸고' 화면은 render 에게 맡긴다.
     4) 데이터가 바뀔 때마다 localStorage 에 저장한다.  → saveState()
   ========================================================= */


/* ---------------------------------------------------------
   1. 요소 선택
   --------------------------------------------------------- */

const tabsBox = document.querySelector('.tabs');
const menuGrid = document.querySelector('.menu-grid');
const cartList = document.querySelector('.cart-list');
const emptyMsg = document.querySelector('.empty-msg');
const totalPriceText = document.querySelector('.total-price');
const totalCountText = document.querySelector('.total-count');
const clearBtn = document.querySelector('.clear-btn');
const orderBtn = document.querySelector('.order-btn');

const modal = document.querySelector('.modal');
const modalPlace = document.querySelector('.modal-place');
const modalNumber = document.querySelector('.modal-number');
const receipt = document.querySelector('.receipt');
const modalTotal = document.querySelector('.modal-total');
const modalClose = document.querySelector('.modal-close');

// 여러 개를 한꺼번에 찾을 때는 querySelectorAll 을 사용.
// 매장 / 포장 버튼 2개
const placeBtns = document.querySelectorAll('.place-btn');



/* ---------------------------------------------------------
   2. 데이터
   --------------------------------------------------------- */

// ★ STEP 2. 카테고리 이름 배열 categories 를 만드세요.
//   ['커피', '논커피', '디저트']

// ★ STEP 2. 메뉴판 배열 menus 를 만드세요. (객체 배열)
//   객체 모양: { id: 번호, name: '이름', price: 가격, category: '분류', icon: '이모지' }
//   - 커피 5개, 논커피 4개, 디저트 4개 (총 13개)
//   - id 는 1부터 차례로, 겹치지 않게 합니다.
//   - 메뉴 이름·가격·이모지는 자유롭게 정해도 됩니다.

// ★ STEP 2. 상태 값(바뀌는 값)을 let 으로 만드세요.



// ★ STEP 4. 장바구니 배열을 let 으로 만드세요.



// ★ STEP 8. 매장/포장 값을 let 으로 만드세요.



// ★ STEP 9. 주문번호를 let 으로 만드세요.




/* ---------------------------------------------------------
   3. 도움 함수
   --------------------------------------------------------- */

// ★ STEP 2. won(number) 함수



// ★ STEP 2. findMenu(id) 함수



// ★ STEP 6. getTotalPrice() 함수 — 총 결제금액



// ★ STEP 6. getTotalCount() 함수 — 총 개수




/* ---------------------------------------------------------
   3-2. 저장하기 / 불러오기          ★ STEP 10 에서 작성
   --------------------------------------------------------- */

// ★ STEP 10. 저장 이름표 상수 STORAGE_KEY 를 만드세요.   예) 'cafe-kiosk-v1'


// ★ STEP 10. saveState() 함수



// ★ STEP 10. loadState() 함수




/* ---------------------------------------------------------
   4. 장바구니 데이터를 바꾸는 함수 (화면은 건드리지 않는다)
   --------------------------------------------------------- */

// ★ STEP 4. addToCart(id) 함수 — 메뉴 담기



// ★ STEP 5. changeQty(id, change) 함수 — 수량 늘리기/줄이기



// ★ STEP 5. removeFromCart(id) 함수 — 삭제




/* ---------------------------------------------------------
   5. 화면 그리기 함수 (render)
   --------------------------------------------------------- */

// ★ STEP 3. renderTabs() 함수 — 카테고리 탭 그리기



// ★ STEP 2. renderMenu() 함수 — 메뉴 카드 그리기



// ★ STEP 8. renderPlace() 함수 — 매장/포장 버튼 모양 맞추기



// ★ STEP 4. renderCart() 함수 — 주문 내역 그리기



//   ★ STEP 6. 목록을 그린 다음, 합계를 화면에 표시한다.



//   ★ STEP 7. 비어 있을 때의 처리




/* ---------------------------------------------------------
   6. 이벤트
   --------------------------------------------------------- */

// ★ STEP 7. 전체 취소 버튼 클릭


// ★ STEP 8. 매장/포장 버튼 클릭


// ★ STEP 9. 주문하기 버튼 클릭  (순서가 중요합니다!)


// ★ STEP 9. 주문 완료 창 닫기




/* ---------------------------------------------------------
   7. 처음 화면 그리기
   --------------------------------------------------------- */

// ★ STEP 2~8. render 함수들을 한 번씩 호출한다. (순서대로)



